export function setAssetName({ commit }, assetName) {
  commit("assetName", assetName);
}
