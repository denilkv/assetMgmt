export function assetName(state, assetName) {
  state.assetName = assetName;
}
