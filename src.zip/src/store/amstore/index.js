import cloneDeep from "lodash/cloneDeep";

import * as actions from "./actions";
import * as mutations from "./ mutations";
//import * as getters from "./getters";

let defaultState = {
  assetName: ""
};

export function createModule() {
  return {
    state: cloneDeep(defaultState),
    //getters,
    actions,
    mutations,
    namespaced: true
  };
}
