export function getAssetName() {
  const getters = {
    assetName: state => state.assetName
  };

  return getters;
}
