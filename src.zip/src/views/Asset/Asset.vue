<template>
  <div class="asset">
    <inner-nav :assetName="assetName"></inner-nav>
    <h1>{{ assetData.asset_name }}</h1>
    <h5>{{ assetData.asset_use }} / {{ assetDistrict }}</h5>
    <map-holder :map-config="mapConfig"
                :position="mapConfig.center"
               apiKey="AIzaSyCweYI--aunve0jHQA_amVW6KWC5ZmlY-A">
    </map-holder>
    <div class="flex-container">
      <div class="flex-item">
        <image-holder :images="assetImages"
                    className="image__single--side"
        ></image-holder>      
      </div>
      <div class="flex-item">
        <accordion>
            <accordion-content>
              <template slot="title">General Information</template>
              <template>
                <ul>
                  <li>District: <span>{{ assetDistrict }}</span></li>
                  <li>Category: <span>{{ assetCategory }}</span></li>
                  <li v-if="assetData.built_year">Built Year: <span>{{ assetData.built_year }}</span></li>
                  <li v-if="assetData.asset_use">Asset Use: <span>{{ assetData.asset_use }}</span></li>
                  <li v-if="assetData.asset_area">Total Boundary Area: <span>{{ assetData.asset_area }}</span></li>
                  <li v-if="assetData.premise_natural">Natural Premises: <span>{{ assetData.premise_natural }}</span></li>
                  <li v-if="assetData.premise_manmade">Man-made Premises: <span>{{ assetData.premise_manmade }}</span></li>
                </ul>
              </template>
            </accordion-content>  

            <accordion-content>
              <template slot="title">Local Information</template>
              <template>
                <ul>
                  <li v-if="assetData.asset_lat">LATITUDE: <span>{{ assetData.asset_lat }}</span></li>
                  <li v-if="assetData.asset_long">LONGITUDE : <span>{{ assetData.asset_long }}</span></li>
                  <li v-if="assetData.asset_block">BLOCK : <span>{{ assetData.asset_block }}</span></li>
                  <li v-if="assetData.asset_village">VILLAGE : <span>{{ assetData.asset_village }}</span></li>
                  <li v-if="assetData.asset_lbn">LOCAL BODY : <span>{{ assetData.asset_lbn }}</span></li>
                  <li v-if="assetData.ward_no">WARD No: <span>{{ assetData.ward_no }}</span></li>
                  <li v-if="assetData.member_name">NAME OF MEMBER : <span>{{ assetData.member_name }}</span></li>
                  <li v-if="assetData.assembly_constituency">KERALA ASSEMBLY CONSTITUENCY : <span>{{ assetData.assembly_constituency }}</span></li>
                  <li v-if="assetData.mla_name">NAME OF MLA : <span>{{ assetData.mla_name }}</span></li>
                  <li v-if="assetData.adj_north">NORTH PRIVATE PROPERTY: <span>{{ assetData.adj_north }}</span></li>
                  <li v-if="assetData.adj_south">SOUTH PRIVATE PROPERTY: <span>{{ assetData.adj_south }}</span></li>
                  <li v-if="assetData.adj_east">EAST ROAD: <span>{{ assetData.adj_east }}</span></li>
                  <li v-if="assetData.adj_west">WEST PRIVATE PROPERTY: <span>{{ assetData.adj_west }}</span></li>
                  <li v-if="assetData.asset_address">ADDRESS: <span>{{ assetData.asset_address }}</span></li>
                  <li v-if="assetData.access_roadtype">ACCESS ROAD TYPE : <span>{{ assetData.access_roadtype }}</span></li>
                  <li v-if="assetData.road_name">ROAD NAME : <span>{{ assetData.road_name }}</span></li>
                  <li v-if="assetData.road_length">ROAD LENGTH : <span>{{ assetData.road_length }}</span></li>
                  <li v-if="assetData.road_width">ROAD WIDTH : <span>{{ assetData.road_width }}</span></li>
                  <li v-if="assetData.distance_junc">DISTANCE FROM JUNCTION : <span>{{ assetData.distance_junc }}</span></li>
                  <li v-if="assetData.nearest_junc">NEAREST JUNCTION : <span>{{ assetData.nearest_junc }}</span></li>
                </ul>
              </template>
            </accordion-content>  

            <accordion-content>
              <template slot="title">Contact Information</template>
              <template>
                <ul>
                  <li v-if="assetData.asset_ownership">OWNERSHIP DETAILS : <span>{{ assetData.asset_ownership }}</span></li>
                  <li v-if="assetData.asset_opdetails">ASSET OPERATIONAL DETAILS : <span>{{ assetData.asset_opdetails }}</span></li>
                  <li v-if="assetData.nodal_officer">NAME OF THE NODAL OFFICER / INCHARGE : <span>{{ assetData.nodal_officer }}</span></li>
                  <li v-if="assetData.nodal_desig">DESIGNATION : <span>{{ assetData.nodal_desig }}</span></li> 
                  <li v-if="assetData.nodal_contact">PHONE NUMBER : <span>{{ assetData.nodal_contact }}</span></li>
                  <li v-if="assetData.nodal_email">Email: <span>{{ assetData.nodal_email }}</span></li>
                  <li v-if="assetData.nodal_website">WEB-SITE : <span>{{ assetData.nodal_website }}</span></li>
                  <li v-if="assetData.nodal_leaseby">LEASING DETAILS : <span>{{ assetData.nodal_leaseby }}</span></li>
                  <li v-if="assetData.land_owned">LAND OWNERSHIP STATUS : <span>{{ assetData.land_owned }}</span></li>         
                </ul>
              </template>
            </accordion-content>  
            
            <accordion-content>
              <template slot="title">Asset & Layout Image</template>
              <template>
                <image-holder :images="assetImages"
                            className="image__single--small"
              ></image-holder>
              </template>
            </accordion-content>     
          </accordion>     
      </div>      
    </div>
  </div> 
</template>

<script>
import assetService from "./api";
import accordion from "@/components/am-accordion";
import imageHolder from "@/components/am-image-holder";
import accordionContent from "@/components/am-accordion/accordion-content";
import mapHolder from "@/components/am-map";
import "./Asset.scss";

export default {
  name: "AssetView",

  data() {
    return {
      assetName: this.name,
      assetServiceData: null,
      assetData: {},
      assetDistrict: null,
      assetCategory: null,
      assetImages: {},
      positionObj: {},
      mapConfig: {
        zoom: 12,
        center: {}
      }
    };
  },
  components: {
    accordion,
    imageHolder,
    accordionContent,
    mapHolder
  },
  created() {
    console.log(this.$store.state.projects);
  },
  async mounted() {
    try {
      this.assetServiceData = new assetService();
      this.assetData = await this.assetServiceData.getAssetInfo(this.assetName);
      this.setCategory();
      this.setDistrict();
      this.setImages();
      this.setLatLong();
    } catch (error) {
      console.log(error);
    }
  },
  props: {
    name: {
      type: String
    }
  },
  methods: {
    setCategory() {
      this.assetCategory = this.assetData.categories[0].category_name;
    },
    setDistrict() {
      this.assetDistrict = this.assetData.districts[0].district_name;
    },
    setImages() {
      this.assetImages = this.assetData.images;
    },
    setLatLong() {
      this.mapConfig.center = {
        lat: this.assetData.asset_lat,
        long: this.assetData.asset_long
      };
    }
  }
};
</script>
