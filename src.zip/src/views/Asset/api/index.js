import axios from "axios";

export default class assetService {
  getAssetInfo(assetSlug) {
    return axios
      .get(`https://api.myjson.com/bins/pe4o0?slug=${assetSlug}`)
      .then(({ data }) => data)
      .catch(err => console.log(err));
  }
}
