import axios from "axios";

export default class asse {
  getDistrictNames() {
    return axios
      .get(`https://api.myjson.com/bins/l4354`)
      .then(({ data }) => data)
      .catch(err => console.log(err));
  }

  getCategoryNames() {
    return axios
      .get(`https://api.myjson.com/bins/q020o`)
      .then(({ data }) => data)
      .catch(err => console.log(err));
  }
}
