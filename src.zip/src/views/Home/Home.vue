<template>
  <div class="flex-container home">
    <list-data class="fade flex-item side-bar" :items="assetCategories" typeName="Category"></list-data>
    <search class="flex-item"></search>
    <list-data class="fade flex-item side-bar" :items="assetDistricts" typeName="District"></list-data>
  </div>
</template>

<script>
import search from "@/components/am-search";
import listData from "@/components/am-list-data/";
import assetTypeService from "./api";
import "./Home.scss";

export default {
  name: "HomeView",

  data() {
    return {
      assetCategories: {},
      assetDistricts: {},
      assetService: null
    };
  },
  components: {
    search,
    listData
  },
  created() {
    this.assetService = new assetTypeService();
    this.setDistricts();
    this.setCategories();
  },
  mounted() { },
  methods: {
    setDistricts() {
      let apiResults = null;

      apiResults = this.assetService.getDistrictNames();
      apiResults
        .then(data => {
          this.assetDistricts = data;
        })
        .catch(err => console.log(err));
    },
    setCategories() {
      let apiResults = null;

      apiResults = this.assetService.getCategoryNames();
      apiResults
        .then(data => {
          this.assetCategories = data;
        })
        .catch(err => console.log(err));
    }
  }
};
</script>
