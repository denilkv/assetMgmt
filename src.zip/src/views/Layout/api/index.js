import axios from "axios";

export default class subAssetService {
  getSubAssetInfo(assetSlug) {
    return axios
      .get(`https://api.myjson.com/bins/1dpoq8?slug=${assetSlug}`)
      .then(({ data }) => data)
      .catch(err => {
        console.log(err);
      });
  }

  getSubAssetFloorInfo(subAssetName) {
    return axios
      .get(`https://api.myjson.com/bins/s74jo?name=${subAssetName}`)
      .then(({ data }) => data)
      .catch(err => console.log(err));
  }

  getInfrastructureInfo(subAssetName) {
    return axios
      .get(`https://api.myjson.com/bins/gvw1w?name=${subAssetName}`)
      .then(({ data }) => data)
      .catch(err => console.log(err));
  }
}
