<template>
  <div class="layout">
    <inner-nav :assetName="assetName"></inner-nav>
    <h1>{{ assetName }}</h1>
    <h5>{{ subAssetData[0].subasset_name }}</h5>
    <ul class="layout__inner-nav">
      <li v-for="(subAssetLink, index) in subAssetData"
          :key="index" 
      >
      <router-link :to="{
        'name': 'Layout',
        params: {
          'name': subAssetLink.subasset_name,
        }
      }"> 
        {{ subAssetLink.subasset_name }} 
      </router-link>
      </li>
    </ul>
   <!-- <image-holder :images="subAssetImages"
                className="image__single--large"
    ></image-holder>    -->
    <div class="flex-container">
      <div class="flex-item">
        <image-holder :images="subAssetData[0].images[0]"
                    className="image__single--side"
                      :isLayout="true"
        ></image-holder>    
      </div> 
      <div class="flex-item">
        <accordion>
            <accordion-content>
              <template slot="title">Structural Information</template>
              <template>
                <ul>
                  <li>SUBASSET NAME : <span> {{ subAssetData[0].subasset_name }}</span></li>
                  <li>SUBASSET AREA : <span> {{ subAssetData[0].subasset_area }}</span></li>
                  <li>NO. OF FLOORS : <span> {{ subAssetData[0].floors_no }}</span></li>
                  <li>STRUCTURE CONDITION : <span> {{ subAssetData[0].structure_condition }}</span></li>
                </ul>
              </template>
            </accordion-content> 
            
            <accordion-content>
              <template slot="title">Floor Information</template>
              <template>
                <ul v-for="(floor, index) in subAssetFloorData"
                    :key="index"
                >
                  <li> FLOOR NO : <span> {{ floor.floor_no }}</span></li>
                  <li> FLOOR TYPE : <span> {{ floor.floor_type }}</span></li>
                  <li> ROOF TYPE : <span> {{ floor.roof_type }}</span></li>
                  <li> NO. OF ROOMS : <span> {{ floor.room_no }}</span></li>
                  <li> FURNISHED : <span> {{ floor.furnished }}</span></li>
                  <li> AIR CONDITIONED : <span> {{ floor.floor_ac }}</span></li>
                  <li> NO. OF AC : <span> {{ floor.no_ac }}</span></li>
                  <li> TYPE OF AC : <span> {{ floor.type_ac }}</span></li>
                  <li> LEAKAGE STATUS : <span> {{ floor.leakage_status }}</span></li>
                </ul>
              </template>
            </accordion-content>
            
            <accordion-content>
              <template slot="title">Infrastructural Information</template>
              <template>
                <ul v-for="(structureData, index) in subAssetStructureData"
                    :key="index"
                >
                  <li> WATER SUPPLY : <span> {{ structureData.water_status }}</span></li>
                  <li> WATER SUPPLY SOURCE: <span> {{ structureData.water_source }}</span></li>
                  <li> ELECTRICITY SUPPLY STATUS: <span> {{ structureData.electricity_status }}</span></li>
                  <li> ELECTRICITY SUPPLY SOURCE: <span> {{ structureData.electricity_source }}</span></li>
                  <li> ELECTRICITY SUPPLY: <span> {{ structureData.electricity_phase }}</span></li>
                  <li> SOLID WASTE MANAGEMENT: <span> {{ structureData.solid_wastemgmt }}</span></li>
                  <li> SEWAGE SYSTEM: <span> {{ structureData.sewage_system }}</span></li>
                  <li> RAIN WATER HARVESTING: <span> {{ structureData.rain_harvest }}</span></li>
                </ul>
              </template>
            </accordion-content>      
              
            <accordion-content>
              <template slot="title">Gallery</template>
              <template>
                <image-holder :images="subAssetData[0].images"
                            className="image__single--small"
              ></image-holder>
              </template>
            </accordion-content>  
          </accordion>        
      </div>
    </div>    
  </div>  
</template>

<script>
import subAssetService from "./api";
import accordion from "@/components/am-accordion";
import imageHolder from "@/components/am-image-holder";
import accordionContent from "@/components/am-accordion/accordion-content";
import "./Layout.scss";

export default {
  name: "LayoutView",

  props: {
    name: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      assetName: this.name,
      subAssetServiceData: null,
      subAssetData: null,
      subAssetImages: {},
      subAssetFloorData: {},
      subAssetStructureData: {},
    };
  },
  components: {
    accordion,
    imageHolder,
    accordionContent
  },
  async mounted() {
    this.subAssetServiceData = new subAssetService();
    this.loadAllSubAssetInformation();
  },
  methods: {
    async getFloorInfo(subAssetName) {
      this.subAssetFloorData = await this.subAssetServiceData.getSubAssetFloorInfo(subAssetName);
    },

    async getInfrastructureInfo(subAssetName) {
      this.subAssetStructureData = await this.subAssetServiceData.getInfrastructureInfo(subAssetName);
    },

    loadAllSubAssetInformation() {
      this.loadSubAssetMaster(this.setSubAssetName());
      this.getFloorInfo(this.setSubAssetName());
      this.getInfrastructureInfo(this.setSubAssetName());
    },
    isDefault(){
      return this.$route.query.default;
    },
    setSubAssetName() {
      return (this.isDefault()) ? this.assetName : "";
    },
    async loadSubAssetMaster(subAssetName) {
        this.subAssetData = await this.subAssetServiceData.getSubAssetInfo(
          subAssetName
        );
    },
  },
};
</script>
