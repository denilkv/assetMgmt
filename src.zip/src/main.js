import Vue from 'vue'
import App from './App.vue'
import router from '@/router'
import store from '@/store'
import './registerServiceWorker'

import appheader from "@/components/am-app-header/";
import appfooter from "@/components/am-app-footer/";
import innernav from "@/components/am-inner-nav/";
import "./assets/scss/main.scss";

Vue.config.productionTip = false

Vue.component("app-header", appheader);
Vue.component("app-footer", appfooter);
Vue.component("inner-nav", innernav);

new Vue({
  router,
  store,
  components: {
    appheader,
    appfooter,
    innernav
  },
  render: h => h(App)
}).$mount('#app')
