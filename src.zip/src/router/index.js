import Vue from "vue";
import Router from "vue-router";
import HomeView from "@/views/Home";
import AssetView from "@/views/Asset";
import LayoutView from "@/views/Layout";
import ListView from "@/views/List";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "Home",
      component: HomeView
    },
    {
      path: "/asset/:name",
      name: "Asset",
      props: true,
      component: AssetView
    },
    {
      path: "/layout/:name",
      name: "Layout",
      props: true,
      component: LayoutView
    },
    {
      path: "/district/:name?",
      name: "District",
      props: true,
      component: ListView
    },
    {
      path: "/category/:name?",
      name: "Category",
      props: true,
      component: ListView
    }
  ]
});
