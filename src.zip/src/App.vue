<template>
	<div id="asset-management">
		<app-header></app-header>
		<router-view></router-view>
		<app-footer></app-footer>
	</div>
</template>

<script>
export default {
  name: "asset-management"
};
</script>
