<template>
  <nav>
      <router-link :to="{
      'name': 'Asset',
      params:{
        'name': assetName,
      }}
      ">Asset Layout</router-link>
      <router-link :to="{
      'name': 'Layout',
      params:{
        'name': assetName,
      },
      query: {
        'default': true,
      }}
      ">Site Layout</router-link>    
  </nav>
</template>

<script>
import "./Inner-nav.scss";

export default {
  name: "inner-nav",
  props: {
    assetName: {
      type: String,
      required: true
    }
  },
  mounted() {
    //console.log(this.assetName);
  }
};
</script>
