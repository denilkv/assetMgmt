import { mount } from "@vue/test-utils";
import autoComplete from "./Autocomplete";

let mockData = [
  {
    name: "Trivvandrum",
    value: "1"
  },
  {
    name: "Puruliya",
    value: "2"
  },
  {
    name: "Kollam",
    value: "3"
  },
  {
    name: "Manali",
    value: "4"
  },
  {
    name: "Bangalore",
    value: "5"
  },
  {
    name: "London",
    value: "6"
  },
  {
    name: "Africa",
    value: "7"
  },
  {
    name: "Moon",
    value: "8"
  },
  {
    name: "Mars",
    value: "9"
  },
  {
    name: "Far Away",
    value: "10"
  }
];

const wrapper = mount(autoComplete, {
  propsData: {
    items: mockData
  }
});

describe("When autocomplete is triggered", () => {
  it("should not throw", () => {
    expect(console.error).not.toThrowError();
  });

  it("should set items for list", () => {
    expect(wrapper.vm.items.length).toBe(mockData.length);
  });

  it("should trigger emit on child", () => {
    wrapper.vm.$emit("listAction", "Trivvandrum");

    expect(wrapper.emitted().listAction).toBeTruthy();
  });

  it("should pass value on emit", () => {
    expect(wrapper.emitted().listAction.length).toBe(1);
  });
});
