<template>
  <ul v-if="checkResultArray()" class="autoComplete">
    <li v-for="(item, i) in this.items" 
        :key="i"
    >
      <a @click="loadAsset(item.name)">
        {{ item.name }}
     </a>   
    </li>
  </ul>
</template>

<script>
export default {
  name: "Autocomplete",

  props: {
    items: {
      type: Array,
      required: true,
      default: () => []
    }
  },

  methods: {
    checkResultArray() {
      return this.items.length > 0;
    },
    loadAsset(assetName) {
      this.$emit("listAction", assetName);
    }
  }
};
</script>
