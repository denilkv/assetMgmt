export { default } from "./Map-provider";
