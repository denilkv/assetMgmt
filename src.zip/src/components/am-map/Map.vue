<template>
  <div>
    <div id="map"></div> <!-- point 1 -->
    <template v-if="!!this.google && !!this.map"> <!-- point 2 -->
      <map-provider
        :google="google"
        :map="map"
      >
        <slot/>
      </map-provider>
    </template>
  </div>
</template>

<script>
import GoogleMapsApiLoader from "google-maps-api-loader";
import MapProvider from "./map-provider";
import "./Map.scss";

export default {
  props: {
    mapConfig: Object,
    apiKey: String,
    position: Object
  },
  components: {
    MapProvider
  },
  data() {
    return {
      google: null,
      map: null
    };
  },
  mounted() {
    // point 3
    GoogleMapsApiLoader({
      apiKey: this.apiKey
    }).then(google => {
      this.google = google;
      this.initializeMap();
      this.setMarker();
    });
  },
  methods: {
    initializeMap() {
      const mapContainer = this.$el.querySelector("#map"); // point 1
      const { Map } = this.google.maps;
      this.map = new Map(mapContainer, this.mapConfig);
    },
    setMarker() {
      const { Marker } = this.google.maps;
      this.marker = new Marker({
        position: this.position,
        map: this.map,
        title: "Child marker!"
      });
    }
  }
};
</script>
