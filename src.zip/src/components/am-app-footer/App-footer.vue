<template>
  <footer class="footer">
    <p> copyright 2018 {{ copyText }}</p>
  </footer>
</template>

<script>
export default {
  name: "App-footer",

  data() {
    return {
      copyText: "Danny Boy"
    };
  }
};
</script>
