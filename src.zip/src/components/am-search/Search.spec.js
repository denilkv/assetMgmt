import { shallowMount } from "@vue/test-utils";
import AxiosMockAdapter from "axios-mock-adapter";
import axios from "axios";
import search from "./Search";

const wrapper = shallowMount(search);

let mockSearchData = {
  choices: [
    {
      name: "Trivvandrum",
      value: "1"
    },
    {
      name: "Puruliya",
      value: "2"
    },
    {
      name: "Kollam",
      value: "3"
    },
    {
      name: "Manali",
      value: "4"
    },
    {
      name: "Bangalore",
      value: "5"
    },
    {
      name: "London",
      value: "6"
    },
    {
      name: "Africa",
      value: "7"
    },
    {
      name: "Moon",
      value: "8"
    },
    {
      name: "Mars",
      value: "9"
    },
    {
      name: "Far Away",
      value: "10"
    }
  ]
};

describe("when search component is accessed", () => {
  let expectedLength;

  beforeEach(function() {
    const input = wrapper.find("input");

    let mock = new AxiosMockAdapter(axios);
    expectedLength = mockSearchData.choices.length;

    input.element.value = "test";
    input.trigger("input");
    mock
      .onGet("https://api.myjson.com/bins/zqopc?key=test")
      .reply(200, mockSearchData);
  });

  afterEach(function() {
    mock.reset();
  });

  it("should have default placeholder", () => {
    expect(wrapper.vm.$data.msg).toBe("Welcome to AM");
  });

  it("search should pass input", () => {
    expect(wrapper.vm.$data.search).toBe("test");
  });

  it("should have auto complete data loaded", () => {
    expect(wrapper.vm.$data.searchResults.length).toBe(expectedLength);
  });
});
