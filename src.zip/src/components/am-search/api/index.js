import axios from "axios";

export default class amSearchService {
  getAssetsbyKey(searchKey) {
    return axios
      .get(`https://api.myjson.com/bins/zqopc?key=${searchKey}`)
      .then(({ data }) => {
        return data;
      })
      .catch(err => {
        console.log(err);
      });
  }
}
