<template>
	<div class="am-search-bar">
		<input  type="text" 
						:placeholder="msg" 
						v-model="search" 
						@input="onUserInput"
		/>
		<autoComplete :items="searchResults" @listAction="loadAsset"></autoComplete>
	</div>
</template>

<script>
import amSearchService from "./api";
import autoComplete from "../am-autocomplete";
import { AMState } from "../../store";

export default {
  name: "search",

  data() {
    return {
      msg: "Welcome to AM",
      search: "",
      amSearch: null,
      searchResults: undefined
    };
  },
  components: {
    autoComplete
  },
  methods: {
    onUserInput() {
      let amSearch = new amSearchService();
      let apiResults = amSearch.getAssetsbyKey(this.search);

      apiResults
        .then(({ choices }) => {
          this.searchResults = choices;
        })
        .catch(err => {
          console.log(err);
        });
    },
    loadAsset(assetName) {
      this.$store.dispatch("LOAD_PROJECT_LIST", assetName);

      this.$router.push({
        name: "Asset",
        params: {
          name: assetName
        }
      });
    }
  }
};
</script>
