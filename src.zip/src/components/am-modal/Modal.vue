<template>
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">
            <slot name="header">
              default header
            </slot>
          </div>

          <div class="modal-body">
            <slot name="body">
              default body
            </slot>
          </div>

          <div class="modal-footer">
            <slot name="footer">
              <div class="btn-group" role="group" aria-label="Modal Controls">
                <button class="btn btn-secondary" @click="$emit('reduce')">
                  -
                </button>                 
                <button class="btn btn-secondary" @click="$emit('enlarge')">
                  +
                </button>              
                <button class="btn btn-secondary" @click="$emit('close')">
                  Close
                </button>
              </div>  
            </slot>
          </div>
        </div>
      </div>
    </div>
  </transition>  
</template>

<script>
export default {
  name: "modal",

  data() {
    return {};
  }
};
</script>
