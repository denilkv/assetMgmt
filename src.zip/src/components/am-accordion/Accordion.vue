<template functional>
  <div class="accordion">
    <slot></slot>
  </div>
</template>
