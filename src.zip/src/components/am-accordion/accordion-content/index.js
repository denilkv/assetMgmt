export { default } from "./Accordion-content";
