<template>
    <div class="accordion__item">
      <h3  @click="toggleSection" 
          class="accordion__title js-title"
      >
        <slot name="title"></slot>
      </h3>
      <div :class="['accordion__copy js-copy', 
                 { 'accordion__copy--open' : isOpen }]"
      >
        <slot></slot>
      </div>
    </div>
</template>

<script>
export default {
  name: "Accordion-content",

  data() {
    return {
      isOpen: false
    };
  },
  methods: {
    toggleSection() {
      this.isOpen = !this.isOpen;
    }
  },
  computed: {
    toggleClass() {
      return {
        "accordion__copy--open": !this.isOpen
      };
    }
  }
};
</script>
