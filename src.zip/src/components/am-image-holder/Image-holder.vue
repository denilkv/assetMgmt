<template>
  <div class="img-holder">
    <ul v-if="!isLayout">
        <li v-for="(image, i) in images"
          :key="i" 
       >
          <img :class="className"
               @click="showModal = true"
               :src="setImageUrl(image.photo_dir, image.photo)" />
            <!-- use the modal component, pass in the prop -->
            <modal  v-if="showModal" 
                    @close="showModal = false" 
                    @enlarge="icreaseWidth()" 
                    @reduce="reduceWidth()"
            >
              <h3 slot="header">{{ setImageName() }}</h3>
              <div class="imageHolder" slot="body">
                <img  :src="setImageUrl(image.photo_dir, image.photo)"
                      ref="image"
                      :style="styleImage"
                />
               </div> 
            </modal>               
        </li>
    </ul>
    <ul v-else>
        <li>
          <img :class="className"
               @click="showModal = true"
               :src="setImageUrl(images.photo_dir, images.photo)" />
            <modal  v-if="showModal" 
                    @close="showModal = false" 
                    @enlarge="icreaseWidth()" 
                    @reduce="reduceWidth()"
            >
            <h3 slot="header">{{ setImageName() }}</h3>
            <img slot="body"
                :src="setImageUrl(images.photo_dir, images.photo)"
                ref="image"
                :style="styleImage"
            />
          </modal>          
        </li>
    </ul>    
  </div>
</template>

<script>
import modal from "@/components/am-modal";

export default {
  name: "Image-holder",

  props: {
    images: {
      type: Object,
      required: true
    },
    className: {
      type: String,
      required: false
    },
    isLayout: {
      type: Boolean,
      required: false
    }
  },
  components: {
    modal
  },
  data() {
    return {
      showModal: false,
      styleImage: {},
    };
  },
  mounted() {},
  methods: {
    setImageUrl(imageLocation, imageName) {
      return `http://demo.prixelmedia.com/asset_mgmt${imageLocation}${imageName}`;
    },
    setImageName() {
      return this.isLayout ? "Layout" : "Gallery";
    },
    icreaseWidth() {
      this.$nextTick(function() {
        let height = `${this.$refs.image.clientHeight * 2}px`;
        let width = `${this.$refs.image.clientWidth * 2}px`;

        this.styleImage = {
          height,
          width
        };
         
      });  
    },
    reduceWidth() {
       this.$nextTick(function() {
        let height = `${this.$refs.image.clientHeight / 2}px`;
        let width = `${this.$refs.image.clientWidth / 2}px`;

        this.styleImage = {
          height,
          width
        };
         
      });       
    }
  }
};
</script>
