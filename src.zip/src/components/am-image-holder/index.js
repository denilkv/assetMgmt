export { default } from "./Image-holder";
