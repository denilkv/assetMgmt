<template>
  <header class="header flex-container">
    <div class="flex-item">
      <img class="logo" src="http://demo.prixelmedia.com/asset_management/assets/images/Logo.png" />
    </div>
    <div class="flex-item">
    <h4>Asset Information System <small>A Directive of Kerala Tourism Department</small></h4>
    </div>
    <div class="flex-item">
      <ul class="app-header-ul">
        <li><router-link :to="{ 'name': 'Home' }">Home</router-link></li>
        <li><a href="#">GIS</a></li>
        <li><router-link :to="{'name': 'Category'}">Categories</router-link></li>
        <li><router-link :to="{'name': 'District'}">Districts</router-link></li>
      </ul>
    </div>
  </header>
</template>

<script>
export default {
  data() {
    return {};
  }
};
</script>
