<template>
  <div>
    <span @click="testMe()">{{ typeName }}</span>
    <ul class="hidden">
      <li v-for="(item,i) in items"
          :key=i
      >
        <router-link :to="{
          'name': typeName,
          params: {
            'name': item, 
          },
        }">
        {{ item }}
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "List-data",
  data() {
    return {};
  },
  props: {
    items: {
      type: Object,
      required: true
    },
    typeName: {
      type: String,
      required: true
    }
  },
  methods: {
    testMe() {
      alert("hi");
    }
  }
};
</script>
